---
name: claude-seo
description: >
  Full-stack SEO audits inside Claude Code with 13 sub-skills, 6 subagents, and DataForSEO MCP integration. Use this skill whenever the user wants to perform SEO analysis, audit a website for SEO issues, check Core Web Vitals, optimize for AI search (Google AI Overviews, ChatGPT, Perplexity), analyze E-E-A-T signals, review schema markup, or conduct technical SEO audits. Triggers on phrases like "SEO audit", "SEO analysis", "Core Web Vitals", "technical SEO", "search optimization", "E-E-A-T", "schema markup", "AI search optimization". Requires Python 3.8+.
---

Skill created by Laxman Meghwal

# claude-seo

**Source:** https://github.com/AgriciDaniel/claude-seo

Full-stack SEO audits inside Claude Code. 13 sub-skills, 6 subagents, DataForSEO MCP.

## Install

```bash
curl -fsSL https://raw.githubusercontent.com/AgriciDaniel/claude-seo/main/install.sh | bash
```

## What it unlocks
- Technical SEO, Core Web Vitals (LCP, INP, CLS), E-E-A-T, schema markup
- AI search optimization: Google AI Overviews, ChatGPT, Perplexity
- DataForSEO MCP: 22 commands across 9 API modules
- Requires: Python 3.8+
