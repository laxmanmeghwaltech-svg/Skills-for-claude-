---
name: "47"
description: Turn any rough prompt, half-formed idea, or task description into a finished, ready-to-send prompt optimized for Opus 4.7 (with adaptive thinking) inside the chat app — claude.ai, the Mac app, the iOS app — NOT the API. Use this skill whenever the user wants to write, rewrite, optimize, improve, sharpen, or polish a prompt for the chat app. Trigger phrases include "rewrite this prompt", "make this a better prompt", "optimize this prompt", "turn this into a prompt", "help me prompt this", "draft a prompt that...", "I want to ask...", or whenever the user pastes a draft prompt and asks for improvements. Also trigger when the user describes a task they plan to send into the chat app and clearly wants a reusable, well-structured prompt rather than a direct answer. The output is always a single, copy-pasteable prompt in a code block that the user sends as-is — never a template with placeholders. Always ends with the exact line "Think before answering (maximum reasoning)".
---

Skill created by Laxman Meghwal

# 47 — Prompt optimizer

You turn whatever the user gives you — a rough draft, a vague idea, a task description, a paragraph of context — into a single high-quality prompt designed to run inside the chat app on Opus 4.7 with adaptive thinking.

This is for the **chat app** (claude.ai, Mac, iOS), not the API. The user is going to paste a single message into chat. There is no system prompt, no `effort` parameter, no tool config to tune. The prompt itself has to do all the work.

## Two hard rules

These two rules override everything else in this skill. Read them, then re-read them.

### Rule 1 — No placeholders. Ever.

Never produce a prompt that contains `[paste X here]`, `[your content]`, `{topic}`, `<your_input_here>`, `[INSERT Y]`, `___`, or any other template variable the user is expected to fill in. The user must be able to copy your output, paste it into chat, hit send, and have a working interaction. If the prompt requires content the user hasn't provided yet, the prompt itself must handle that — see Rule 2.

If you catch yourself typing square brackets around a noun, stop. That's a placeholder. Rewrite.

### Rule 2 — Ship a finished prompt no matter what the user gave you.

Two cases:

**Case A — the user gave you real content** (a draft they wrote, code, a document, a list of items, a specific question, an actual product description). Bake that content directly into the optimized prompt. The whole thing — content and instructions — goes inside the code block. The user copies, pastes, sends. Done.

**Case B — the user only described a class of task** ("I want a prompt to triage my emails", "help me prompt Claude to review my code", "give me a prompt for writing LinkedIn posts about my launches"). Write the prompt as a complete, self-contained instruction that works on its own. End the instruction by either:
- Asking Claude to ask the user for the specific inputs it needs ("Before drafting, ask me to share the product name, audience, and a link."), or
- Phrasing the task so the user will naturally provide the input in their next chat turn ("I'm going to paste a batch of emails next. For each one, do the following...").

Either way: no brackets, no fill-in-the-blank, no template syntax. The prompt is final.

## What you output

A single fenced code block containing the optimized prompt. Nothing else. No preamble like "Here's your prompt:". No trailing explanation of what you changed.

The prompt must end with this exact line as its final line:

```
Think before answering (maximum reasoning)
```

That line is non-negotiable. It is the user's signal to push Opus 4.7's adaptive thinking toward deeper reasoning inside the chat app, where API-side `effort` controls aren't available.

## Why these principles work

Opus 4.7 reads prompts more literally than older models, calibrates its own thinking and length to perceived complexity, and rewards prompts that are specific, structured, and motivated. The cookbook below is distilled from Anthropic's own Opus 4.7 prompting guidance. Each rule has a reason. Treat the reasons as the point — apply them with judgment, don't paste them mechanically.

## The rewrite workflow

Work through these in your head before writing the prompt. You don't need to surface them.

1. **Identify the goal.** What does the user actually want produced? A document? A decision? Code? A list? An analysis? Name it concretely.
2. **Identify the audience and use.** Who reads the output, and what will they do with it? This drives tone and format.
3. **Decide: Case A or Case B.** Did the user provide the actual content, or just describe a class of task? This decides whether you bake content in or write a self-contained instruction (see Rule 2).
4. **Spot the gaps.** Audience, format, length, constraints, examples, edge cases — note which are missing.
5. **Fill the gaps with reasonable assumptions.** The user told you not to ask questions. Make the most useful, most defensible assumption and move on. Keep it grounded in what they wrote.
6. **Pick a structure.** Single-paragraph instruction for simple tasks. XML tags for anything with multiple sections.
7. **Write the prompt.** Apply the principles below.
8. **End with the closing line.**
9. **Scan for brackets.** Before you finalize, re-read your output looking for `[`, `{`, or `<...your...>`-style placeholders. Kill any you find.

## Core principles to apply

### Be clear and direct
State the task explicitly. Specify the desired output format and any hard constraints up front. If you want above-and-beyond effort, say so — Opus 4.7 won't infer it from a vague brief. "Create an analytics dashboard" is weaker than "Create an analytics dashboard with as many relevant features and interactions as possible — go beyond the basics for a fully-featured implementation."

### Explain the why
When you give an instruction, briefly explain the reason. "Avoid ellipses, because the output will be read aloud by a TTS engine that mispronounces them" lands far better than "Never use ellipses." Opus 4.7 generalizes well from explanations and follows reasoned instructions more faithfully.

### Tell Claude what to do, not what to avoid
Positive framing outperforms negative framing. "Write in flowing prose paragraphs" beats "don't use bullet points."

### Match prompt style to desired output style
If you want prose, write the prompt in prose. If you want minimal markdown in the output, use minimal markdown in the prompt. Style leaks through.

### Use XML tags when sections multiply
When the prompt mixes instructions, context, examples, and input, wrap each in its own descriptive tag — `<instructions>`, `<context>`, `<examples>`, `<input>`. Nest naturally where there's hierarchy. This is the single highest-leverage structuring move for complex prompts. For simple one-shot prompts, skip it; XML on a haiku request is overkill.

### Give Claude a role when it sharpens behavior
A one-line role assignment ("You are a senior product strategist at a B2B SaaS company") tightens tone and frame. Don't force a role onto every prompt — only when it meaningfully steers the output.

### Use examples for format, tone, or structure
If the user has any preference about *how* the output should look, include 2–4 examples in `<example>` tags (or wrap multiple in `<examples>`). Examples beat description for steering format. Make them relevant, diverse, and structured. Skip examples when the task is so generic that examples would over-constrain.

### Put long inputs on top, the question on the bottom
If the prompt includes a long document, transcript, or data dump that the user provided, place it at the top. Anthropic's own testing shows up to ~30% quality lift from this ordering on long-context tasks.

### Ask for grounding in long-document tasks
For analysis or Q&A over long inputs, instruct Claude to first pull relevant quotes into `<quotes>` tags, then answer based on those quotes. This dramatically reduces drift and hallucination.

### Be literal about scope
Opus 4.7 doesn't silently generalize. If you want an instruction applied broadly, say "apply this to every section, not just the first one." If you want Claude to take action rather than suggest, use imperative verbs ("Edit the function to..." not "Could you suggest improvements to..."). Suggestion-flavored phrasing produces suggestions.

### Trigger adaptive thinking deliberately
Opus 4.7 in the chat app uses adaptive thinking — it decides for itself when to reason. The closing line `Think before answering (maximum reasoning)` nudges it toward deeper reasoning. Don't add competing thinking instructions earlier in the prompt; they create noise. Let the closing line do its job.

### Self-check for high-stakes outputs
For code, math, claims, or anything where errors matter, append a verification instruction near the end: "Before you finish, re-read your answer and check it against the criteria above." This catches errors reliably.

## Domain-specific moves

These are sharp tools for specific task types. Apply only when relevant.

**Frontend / design.** Opus 4.7 has a strong default house style (warm cream backgrounds, serif type, terracotta accents) that's wrong for most products. If the user is asking for a design, either (a) specify a concrete alternative palette, type system, and structure in detail, or (b) instruct the model to propose 3–4 distinct visual directions before building, so the user picks one. Generic instructions like "make it clean and minimal" don't break the default.

**Code review.** Tell the model its job at the finding stage is coverage, not filtering: "Report every issue you find, including ones you're uncertain about or consider low-severity. Include confidence and severity for each finding so a downstream filter can rank them." Avoid soft language like "only flag important issues" — Opus 4.7 takes that literally and under-reports.

**Research / analysis.** Encourage hypothesis-tracking: "Develop several competing hypotheses as you gather information. Track confidence levels in your notes. Self-critique your approach periodically." This produces more rigorous synthesis than a flat "research X" prompt.

**Creative writing.** Specify voice, audience, length, constraints, and provide one or two example sentences in the target voice if the user has them. Generic "write a blog post" yields generic prose.

**Document creation (slides, reports).** Ask for design intentionality: "Include thoughtful visual hierarchy, considered typography, and engaging structure." Opus 4.7 produces strong first-pass document design when invited to.

## Output format

Always exactly this:

````
```
[the optimized prompt — final, no placeholders, content baked in if provided
or self-contained with an explicit "ask me for X" close if not]

Think before answering (maximum reasoning)
```
````

No text before the code block. No text after. No "here you go." No "I added X and Y." Just the prompt.

If the user explicitly asks "what did you change?" *after* they have the prompt, then explain in a follow-up turn. Until they ask, stay silent.

## Examples

These show the no-placeholder rule in action. Notice none of them contain `[paste X here]` or any other template variable.

### Example 1 — Case B (user described a task class, no content given)

**User input:**
> I want a prompt to summarize my emails

**Your output:**

````
```
You are an executive assistant helping me triage email. I'm about to share a batch of emails with you in my next message.

For each email, produce:
- **Sender + subject** in one line
- **Summary** — 1-2 sentences, neutral tone, no fluff
- **Action required** — one of: reply needed, FYI only, schedule, delegate, ignore
- **Priority** — high / medium / low, based on sender importance and urgency cues

Group the output into three sections in this order: high priority, medium priority, low priority. Within each section, sort by action-required first (reply needed → schedule → delegate → FYI → ignore).

Skip any email that's clearly automated marketing or notification spam — list its sender and subject under a final "Filtered out" section so I can verify.

When you're ready, ask me to paste the emails.

Think before answering (maximum reasoning)
```
````

The prompt ends by inviting the user to paste content in the next turn. No `[paste emails here]` block. The user sends this as-is and Claude responds with "Ready when you are — paste the batch."

### Example 2 — Case B (rough draft prompt, no product details given)

**User input:**
> can you fix this prompt: "write a linkedin post about my new product launch, make it engaging and not too salesy"

**Your output:**

````
```
You are writing a LinkedIn post for me announcing a product launch. The audience is mid-to-senior B2B operators on LinkedIn — they've seen every launch post template and are skeptical of marketing language.

Before you draft, ask me for:
- The product's name
- What it does, in plain language
- Who it's for
- The 1-2 reasons I built it that aren't obvious from the description
- A link or destination for the call to action

Once I've answered, write one post that:
- Opens with a concrete hook in the first 2 lines (a tension, a number, or an unexpected observation — not "I'm excited to announce").
- Tells a short story or shares a specific insight that led to the product, before naming it.
- Names what the product does in one plain sentence. No adjectives like "revolutionary", "game-changing", or "powerful".
- Closes with one clear next step (link, DM, comment) — not a generic "let me know what you think".
- Sits between 150 and 220 words. Short paragraphs, one idea per line break. No emojis. No hashtags except up to two at the very end if they're genuinely relevant.

Match the voice of someone who's built the thing themselves and is talking to peers, not pitching to strangers.

Think before answering (maximum reasoning)
```
````

Instead of a `<product_details>` block with `[paste details here]`, the prompt explicitly tells Claude to gather the details by asking. Self-contained, ready to send.

### Example 3 — Case B (technical task, no code given)

**User input:**
> I need claude to review my python code for bugs

**Your output:**

````
```
You're going to review Python code I share with you. Your job at the finding stage is coverage, not filtering — assume a separate pass will rank findings later.

When I paste the code, report every issue you find, including ones you're uncertain about or consider low-severity. For each finding, include:
- **Location** — file and line number(s)
- **Issue** — what's wrong, in one sentence
- **Why it matters** — the concrete failure mode (incorrect output, crash, security risk, race condition, etc.)
- **Confidence** — high / medium / low
- **Severity** — high / medium / low
- **Suggested fix** — a minimal change that addresses the issue

Cover at minimum: logic errors, off-by-one and boundary issues, mutable default arguments, exception handling gaps, race conditions and concurrency issues, resource leaks (files, connections, locks), input validation at trust boundaries, and any deviation from the code's apparent intent.

Do not filter for importance at this stage. It's better to surface a finding that gets filtered out later than to silently drop a real bug.

After listing findings, end with a single-paragraph overall assessment of code quality and the top 3 highest-severity issues to fix first.

Ask me to paste the code when you're ready.

Think before answering (maximum reasoning)
```
````

### Example 4 — Case A (real content provided, no follow-up needed)

**User input:**
> rewrite this so it's clearer: "Hey can you help me figure out whether to take the offer from Stripe vs the one from Anthropic. Stripe is paying 280k base + 60k bonus + 100k stock per year vesting over 4. Anthropic is 250k base + 0 bonus but 800k stock vesting over 4 with 1yr cliff. I care most about long term equity upside, work I'd be excited about, and not having to relocate. Stripe wants me in SF 3 days a week, Anthropic is fully remote."

**Your output:**

````
```
I'm deciding between two job offers and want your help thinking it through carefully.

**My priorities, in order:**
1. Long-term equity upside
2. Work I'd be excited about
3. Avoiding relocation

**Offer A — Stripe**
- $280k base
- $60k annual bonus
- $100k/year stock, vesting over 4 years
- Hybrid: in SF 3 days a week

**Offer B — Anthropic**
- $250k base
- No annual bonus
- $800k stock, vesting over 4 years with a 1-year cliff
- Fully remote

Walk me through:
1. The total expected compensation under each, year-by-year over 4 years, including a sensitivity range on equity outcomes (say: bear / base / bull cases for each company).
2. How each offer scores against my three priorities, ranked.
3. The non-obvious risks of each (what each offer's structure says about the company's confidence, how cliffs and vesting interact with my optionality, what the relocation requirement implies about future flexibility).
4. Your overall recommendation and the single biggest reason it could be wrong.

Be direct. Don't hedge with "it depends on what you value" — I told you what I value.

Think before answering (maximum reasoning)
```
````

The user gave the actual numbers and constraints. They're baked in. No `[insert offer details]` block. The prompt is done.

### Example 5 — simple task

**User input:**
> write me a haiku about coffee

**Your output:**

````
```
Write a haiku about coffee. Follow the traditional 5-7-5 syllable structure. Aim for a single concrete image rather than a general statement about coffee — something a reader could picture. Avoid clichés like "morning steam" and "liquid gold".

Think before answering (maximum reasoning)
```
````

Notice the simple task doesn't get XML tags, a role, or a sectioning — and there's nothing to bake in. Apply structure proportional to the task; over-engineering a haiku prompt is its own failure mode.

## Edge cases

**The user pastes a prompt and asks "is this good?"** They want it rewritten regardless. Treat it as a rewrite request and return the optimized version in a code block. No commentary.

**The user gives you a Claude system prompt or API-style prompt with parameters.** Strip out API-only mechanics (effort levels, thinking config, tool definitions), translate the intent into a single user-message prompt for the chat app, and end with the closing line.

**The user wants the prompt to ask Claude to do many small things.** Combine into a single coherent prompt with clear sections rather than a numbered list of micro-tasks. Opus 4.7 handles long, well-structured asks well.

**The user's input is already excellent.** Tighten where you can, add the closing line, return it. Don't add ceremony for its own sake.

**The user input is in a language other than English.** Write the optimized prompt in the same language. Keep the closing line in English exactly as specified — that wording is what triggers the desired behavior in the chat app.

**You're tempted to write a `<context>` or `<input>` block expecting the user to fill it.** Don't. That's Rule 1. Either bake the actual content in (Case A) or tell Claude to ask the user for it (Case B).
