---
name: ui-ux-pro-max
description: >
  AI-powered design intelligence with 161 design rules, 67 UI styles, 57 font pairings, and 161 color palettes. Use this skill whenever the user wants to apply professional UI/UX design patterns, choose a UI style for their project, get font pairing recommendations, select color palettes, or follow industry-specific design rules (SaaS, fintech, healthcare, e-commerce). Triggers on phrases like "UI design", "UX rules", "design system", "font pairing", "color palette", "glassmorphism", "bento grid", "brutalist", "neumorphism", "UI style", "design intelligence". Supports React, Vue, Flutter, and SwiftUI frameworks.
---

Skill created by Laxman Meghwal

# ui-ux-pro-max

**Source:** https://github.com/nextlevelbuilder/ui-ux-pro-max-skill

AI-powered design intelligence. 161 design rules, 67 UI styles, 57 font pairings, 161 color palettes.

## Install

```bash
npm install -g uipro-cli
uipro init --ai claude
```

## What it unlocks
- Industry-specific rules: SaaS, fintech, healthcare, e-commerce
- UI styles: glassmorphism, bento grid, AI-native, brutalist, neumorphism
- Framework support: React, Vue, Flutter, SwiftUI
