---
name: agent-browser
description: >
  Headless browser automation CLI built for AI agents with ref-based element control. Use this skill whenever the user wants to automate browser tasks, scrape web pages, interact with websites programmatically, fill forms, click elements, take screenshots, or perform any browser-based testing or automation. Triggers on phrases like "browser automation", "web scraping", "headless browser", "agent browser", "automate browser", "click element", "fill form", "web testing". Requires Node.js and npm.
---

Skill created by Laxman Meghwal

# agent-browser

**Source:** https://github.com/vercel-labs/agent-browser

Headless browser automation CLI built for AI agents. Ref-based element control, no clean API needed.

## Install

```bash
npm install -g agent-browser
agent-browser install
```

## What it unlocks
- Stable @ref-based element targeting — deterministic, agent-friendly
- Click, fill, scroll, upload, drag, intercept network requests
- Parallel sessions with persistent cookie/auth state
- Cloud providers: Browserbase, Browser Use, Kernel
