---
name: superpowers
description: >
  Complete agentic dev workflow: brainstorm, spec, plan, subagent execution, review, and merge. Use this skill whenever the user wants to follow a structured development loop, dispatch subagents for parallel task execution, enforce TDD (RED-GREEN-REFACTOR), run brainstorm-to-merge workflows, or work with git worktrees for isolated feature development. Triggers on phrases like "agentic workflow", "superpowers", "structured dev loop", "brainstorm spec plan", "subagent execution", "TDD workflow", "git worktree".
---

Skill created by Laxman Meghwal

# superpowers

**Source:** https://github.com/obra/superpowers

Complete agentic dev workflow: brainstorm → spec → plan → subagent execution → review → merge.

## Install

Via Claude Code plugin marketplace (search: superpowers)

Or:
```bash
git clone https://github.com/obra/superpowers ~/.claude/skills/superpowers
```

## What it unlocks
- Structured loop: brainstorm → design doc → git worktree → subagent tasks → review
- Subagents dispatched per task with two-stage code review
- Enforces TDD: RED-GREEN-REFACTOR, no code before a failing test
- 40.9K GitHub stars
