---
name: linkedin-content-creator
description: >
  Create high-performing LinkedIn posts, carousels, and infographics in the style of top creators like Charlie Hills, Chris Donnelly, Vaibhav Sisinty, Ruben Hassid, and Lara Acosta. Use this skill when writing LinkedIn content, creating social media posts for professional audiences, designing carousels or infographics, building personal brands, crafting thought leadership content, or when the user mentions LinkedIn, professional networking, B2B content, viral posts, engagement strategies, or any of these creator names.
---

Skill created by Laxman Meghwal

# LinkedIn Content Creator

## Overview

This skill helps you create scroll-stopping LinkedIn content that drives engagement, builds authority, and generates leads. It draws on the proven strategies of top LinkedIn creators who collectively reach millions of professionals.

## Core Content Formats

### Text Posts

**Structure:**
- Hook (first 1-2 lines): Stop the scroll with curiosity, controversy, or a bold claim
- Body: Short sentences. One idea per line. White space matters.
- Close: Clear CTA or thought-provoking question

**Style principles:**
- Write like you talk. Conversational, not corporate.
- Use specific details over vague adjectives
- Short sentences create rhythm and readability
- Break paragraphs after 2-3 lines maximum
- Avoid AI clichés: "delve," "unlock," "leverage," "game-changer," "tapestry"

**Hook patterns that work:**
- Contrarian: "Everyone says X. Here's why they're wrong."
- Number-driven: "I analyzed 500 posts. Here are the 3 patterns."
- Story opening: "I lost $50K in 3 months. Here's what I learned."
- Pattern interrupt: "Stop doing X. Do this instead."
- Curiosity gap: "This one change doubled my engagement."

### Carousels (PDF Documents)

**Why carousels work:**
- Generate 3.4x more reach than single images
- Increase dwell time, signaling value to the algorithm
- Average engagement rate: 1.92% (vs 0.8% for static images)
- Highly shareable and saveable

**Optimal specifications (2026):**
- Format: PDF upload (renders as swipeable slides)
- Dimensions: 1080 x 1350 pixels (4:5 portrait ratio) for maximum mobile screen real estate
- Alternative: 1080 x 1080 pixels (1:1 square) for desktop optimization
- Slide count: 5-10 slides (sweet spot is 7)
- File size: Under 10MB
- Font size: Headers 40-60pt, body 24-36pt
- DPI: 300 minimum

**Carousel structure:**
1. **Cover slide**: Bold hook with number or promise. High contrast, minimal text.
2. **Problem/Context**: Establish the pain point or opportunity
3. **Core value slides (3-5)**: One main idea per slide. Use diagrams, icons, or visual hierarchy.
4. **Summary/Key takeaway**: Reinforce the main message
5. **CTA slide**: Tell them exactly what to do next (follow, comment, visit link, download resource)

**Design principles:**
- High contrast (black text on white or bold brand colors)
- Consistent branding: colors, fonts, logo placement
- Minimal text: 10-20 words per slide maximum
- Visual cues: arrows, progress bars, numbered steps
- White space: don't overcrowd slides
- Use icons, diagrams, or simple illustrations to support ideas

**Caption for carousel posts:**
- Don't repeat the carousel content
- Tell a personal story or provide context
- Position the carousel as the "cheat sheet" or resource
- Include 3-5 relevant hashtags
- Tag collaborators or featured people (not random influencers)

### Infographics

**Best formats for LinkedIn:**
- Single-insight graphics: One stat or concept, visually striking
- Data stories: Present research findings or industry statistics
- Step-by-step guides: Practical how-to visuals
- Comparison charts: Before/after, this vs that
- Framework diagrams: Visual models or processes

**Specifications:**
- Single image: 1200 x 627 pixels (landscape) or 1080 x 1080 (square)
- Infographic: 1080 x 1350 pixels (portrait) for feed dominance
- File format: PNG or JPEG
- Max file size: 5MB

**Design approach:**
- Lead with the insight, not decoration
- Use data to build credibility
- Professional, clean layouts
- Brand consistency across all graphics

## Creator Style Profiles

### Charlie Hills

**Focus:** AI-powered LinkedIn growth, marketing technology, authentic content creation

**Style traits:**
- Teaches systems and frameworks (e.g., CHEF Framework: Curate, Heat, Enhance, Feed)
- Emphasizes AI tools but warns against "AI slop"
- Data-driven: shares specific numbers, results, and methods
- Transparent about tools and workflows
- Uses carousels and infographics extensively
- Tone: Practical, educational, no-fluff

**Content patterns:**
- Tool breakdowns with step-by-step instructions
- "Here's my exact system" posts
- AI content creation workflows
- Carousel tutorials on LinkedIn growth
- Emphasis on authenticity: "AI should amplify you, not replace you"

### Chris Donnelly

**Focus:** Personal branding, entrepreneurship, leadership, emotional intelligence

**Style traits:**
- Empathetic and direct tone
- Blends personal stories with practical advice
- Short, punchy sentences
- Rarely uses humor or sarcasm
- Feels like a mentor, not a marketer
- Heavy use of image-based posts (57%) and carousels (32%)

**Content patterns:**
- Listicles: "8 ways to improve workplace culture"
- Bold opening statements followed by numbered insights
- Emotional hooks: "People don't quit bad jobs. They quit bad managers."
- Focus on pre-validated content (what already works)
- Data-driven approach to content strategy

**Hook examples:**
- "People don't just quit bad jobs."
- "15 Uncomfortable Truths Every Employer Should Read"
- "You're not busy. You're unorganized."

### Vaibhav Sisinty

**Focus:** LinkedIn growth hacking, outbound strategies, storytelling, growth marketing

**Style traits:**
- Growth hacker mentality: tests everything
- Emphasizes "broetry" style (single-line story format)
- Teaches engagement pods and algorithm tactics
- Focus on personal brand as lead generation
- Practical, tactical advice

**Content patterns:**
- Story-driven posts: hero's journey format
- Profile optimization tips
- Outbound connection strategies
- LinkedIn algorithm insights
- Workshop-style teaching

### Ruben Hassid

**Focus:** AI content creation, automation, LinkedIn video, tool recommendations

**Style traits:**
- Early adopter of AI tools
- Founder of EasyGen (AI content platform)
- Uses AI avatars for video content
- Highly visual, tool-focused content
- Fast-paced, trend-driven

**Content patterns:**
- "This AI tool will change everything" posts
- Step-by-step tool tutorials
- AI-generated visuals and videos
- Exclusive community offers (WhatsApp channels)
- Emphasis on efficiency and scale

### Lara Acosta

**Focus:** Personal branding, LinkedIn growth, content strategy, founder marketing

**Style traits:**
- Co-founder of Kleo (AI LinkedIn tool)
- Ranked #1 female creator in UK
- Data-driven content strategy
- Emphasis on quality over quantity
- Clear, actionable frameworks

**Content patterns:**
- "Here's exactly how I grew to X followers" posts
- Content audits and analysis
- 70-20-10 content mix (teaching/proof/selling)
- Hook-focused writing
- Playbooks and downloadable resources

**Key principle:** "Raise the bar for every single post you write."

## Content Strategy Framework

### The 70-20-10 Mix

- **70% Teaching**: Frameworks, tips, how-tos, educational content
- **20% Proof**: Case studies, results, personal stories, social proof
- **10% Selling**: Offers, signups, launches, direct CTAs

### Pre-Validated Content Approach

Before creating:
1. Research what's already working in the niche
2. Analyze top-performing posts from similar creators
3. Identify patterns in hooks, formats, and topics
4. Adapt successful frameworks with your unique voice

### Engagement Strategy

**Before posting:**
- Engage with your network 1 hour before publishing
- Comment on 5-10 posts from your target audience

**After posting:**
- Respond to every comment in the first hour
- Ask follow-up questions to drive conversation
- Engage with others' content 1 hour after posting

**Community building:**
- 80% engagement with your target audience
- 20% engagement with bigger creators (for visibility, not validation)
- Reply to DMs consistently
- Build real relationships, not transactional connections

## Algorithm Insights (2026)

**What the algorithm rewards:**
- Dwell time: How long people spend on your post
- Swipes and clicks: Especially on carousels
- Meaningful comments: Not just "Great post!"
- Shares and saves: Strong signals of value
- Early engagement velocity: First 1-3 hours matter most

**What to avoid:**
- External links in posts (use first comment instead)
- Overuse of hashtags (3-5 is optimal)
- Generic AI language
- Posting at random times (consistency matters)
- Engagement bait ("Tag someone who needs this")

## Practical Workflow

### For Text Posts

1. **Hook first**: Write 5 different hooks, pick the strongest
2. **Body**: One idea per line. Use white space.
3. **CTA**: Make it specific and low-friction
4. **Review**: Read aloud. Does it sound like you?
5. **AI check**: Remove any corporate jargon or AI tells

### For Carousels

1. **Choose a topic**: What can you teach in 5-7 slides?
2. **Outline**: One key idea per slide
3. **Design**: Use Canva, Figma, or AI tools (Gemini, ChatGPT with DALL-E)
4. **Export**: PDF format, 1080x1350px
5. **Caption**: Story or context, not a repeat of slides
6. **Upload**: As document post, not image

### For Infographics

1. **Lead with insight**: What's the one thing people need to know?
2. **Visualize data**: Use charts, icons, or diagrams
3. **Keep it simple**: One message per graphic
4. **Brand consistency**: Colors, fonts, logo
5. **Caption**: Expand on the visual with context

## Quality Checklist

Before posting, ask:
- [ ] Does the hook stop the scroll?
- [ ] Is it conversational, not corporate?
- [ ] Have I removed AI clichés?
- [ ] Does it provide specific value?
- [ ] Is there a clear CTA?
- [ ] Would I engage with this if someone else posted it?
- [ ] Is it optimized for mobile viewing?

## Tools & Resources

**Design:**
- Canva (templates, easy export)
- Figma (collaborative, professional)
- Draftly (LinkedIn carousel builder)
- Google Gemini (AI-generated infographics)

**Content creation:**
- NotebookLM (voice and style learning)
- ChatGPT / Claude (first drafts, never final copy)
- AuthoredUp (post analytics and archive)

**Research:**
- Apify (scrape LinkedIn, X, Reddit for trending topics)
- Taplio (analytics and inspiration)
- LinkedIn native analytics (post-level performance)

**Scheduling:**
- Buffer, Hootsuite, or SocialPilot
- Best posting times: Weekdays 7-9am, 12-1pm, 5-6pm (test for your audience)

## Common Mistakes to Avoid

1. **Posting without engaging**: Content alone won't build your network
2. **Ignoring comments**: Reply to everyone, especially early
3. **Inconsistent posting**: Algorithm rewards frequency
4. **Too much selling**: Lead with value, not pitches
5. **Generic hooks**: "I want to talk about X today" doesn't stop scrolls
6. **Overdesigned carousels**: Clarity beats complexity
7. **No CTA**: Tell people what to do next
8. **Copying without adapting**: Learn from others, but use your voice

## Measuring Success

**Engagement metrics:**
- Engagement rate: (Likes + Comments + Shares) / Impressions
- Dwell time: How long people spend on your post
- Click-through rate: Especially for carousels
- Profile visits: Are posts driving discovery?

**Business metrics:**
- Inbound leads or DMs
- Newsletter signups
- Website traffic from LinkedIn
- Actual revenue or opportunities generated

**Content insights:**
- Which topics resonate most?
- Which formats drive the most engagement?
- What time/day performs best?
- Which hooks get the most clicks?

Track monthly. Iterate based on data, not assumptions.