---
name: hook-writer
description: Generate powerful, concise social media hooks that capture attention. Use this skill when the user mentions "hook," "hooks," "write a post," "create a post," "caption for," "opening line," "first sentence," or any request involving social media content creation that needs an attention-grabbing start. Works automatically with conversation context and memories - no rigid questions required.
---

Skill created by Laxman Meghwal

# Hook Writer

Generate 2-3 powerful hook options for social media posts using proven formulas as creative inspiration. Work seamlessly with conversation context and Claude's memories about the user's audience and niche.

## Core Rules (NEVER violate these)

- NEVER start hooks with a question
- NEVER use salesy buzzwords: discover, skyrocket, revolutionize, digital landscape, unleash, elevate, supercharge, unlock, boost, dive, journey, embark, navigate
- Keep hooks concise (typically 8-13 words, but prioritize impact over strict count)
- Include actual numbers (not spelled out) when relevant
- Use parentheses strategically to reinforce the hook
- Match the tone and voice of strong, proven hooks (direct, bold, clear)

## Hook Formula Categories (Use as Inspiration)

These formulas are creative guidelines, not rigid templates. Choose what fits naturally.

### 1. Delete Pain Point
Format: How to [desired result] (without [pain point])

**Examples:**
- "How I used AI to create 9 reels in 6 minutes (without crappy results)"
- "5 ways to 10X your outbound sales (without hiring more sales reps)"
- "3 fast ways to get rid of acne and avoid embarrassment"

### 2. Bold Statement
Format: Bold claim (8 words max) + Counterpoint + Optional actionable step

**Examples:**
- "AI writes better than humans. But creativity remains a human domain. Blend both perfectly in 3 steps👇"
- "Copywriting is an art form. But even art has a science behind it. Master it with these 3 AI tools👇"
- "Memes capture attention instantly. But they also need clever crafting. Here's how to create viral memes in 5 steps👇"

### 3. Challenge
Format: How to [desired result] (even if [pain point])

**Examples:**
- "How to be a key person of influence (even if you have 0 followers)"
- "How to craft compelling stories that draw attention (even if you think you're a bad writer)"
- "5 quick and easy ways to get a higher PT test score (even if you failed your last test)"

### 4. Credibility (Only use if social proof is available)
Format: I spent [time/money] doing X. Here's what I learned

**Examples:**
- "I spent 27+ hours testing the top 100 GPTs. Here are my favorite 5:"
- "How our outreach tool helped a company add $100k MRR in 30 days"
- "5 ways to 10X your outbound sales (from a SaaS tool that increased one company's MRR by $100k)"

**Important:** Only use this formula if the user has actual social proof. Don't fabricate credentials.

### 5. Big Promise (Most Creative - Use When Formulas Don't Fit)

This is your creative freedom option. Use when formulas feel restrictive or when you want maximum intrigue.

**Strong vs. Generic Examples:**

| Generic | Strong |
|---------|--------|
| 5 ways a content strategy fails | 5 plagues of a content strategy for career coaches (and THE best alternative) |
| How to get a six pack | The secret strategy time-poor CEOs use to get bodies of Greek gods in 3 hours per week |
| Tip of the day for buying an investment property | Calling out all frustrated first-time investors... I am about to change the way you search for homes in 20 seconds |
| Public speaking hack | Here's how to get an Olympic gold medal with your next speech |
| Why should you hire a ghostwriter? | 5 surprising reasons that hiring a ghostwriter may be the best thing you do in 2024 |

## Your Process

### 1. Work with Available Context

Use information from:
- The user's current message (post idea, content, topic)
- Conversation history (previous discussions about their content)
- Claude's memories (audience, niche, business details)
- Any context naturally mentioned

### 2. Fill in Intelligently

If something is missing:
- Infer from context when reasonable (e.g., if they're a fitness coach talking about nutrition, the audience is likely people wanting to get healthier)
- Make educated assumptions based on memories
- ONLY ask clarifying questions if absolutely critical and nothing can be inferred

### 3. Select the Best Approach

Don't force all formulas. Choose 1-2 formulas that naturally fit the content, OR use the Big Promise approach for creative freedom.

### 4. Generate 2-3 Hook Options

Create variations that:
- Match the post's tone and purpose
- Feel natural, not forced into a formula
- Prioritize clarity and impact over strict formula adherence
- Use the formulas as inspiration, not rigid templates

### 5. Just Deliver

Skip preamble. No "let me analyze" or "based on your context" - just give them the hooks.

## How to Handle Context

**Scenario 1: User gives full context**
"I want to write a post about how coaches can get more Instagram followers without posting every day"
→ You have everything. Generate hooks immediately.

**Scenario 2: User gives partial context + you have memories**
"Can you write a hook for my post about client acquisition?"
→ Check memories for their niche/audience. Generate hooks using that context.

**Scenario 3: Minimal info but inferable**
"Hook for a post about time management"
→ Infer common pain points (feeling overwhelmed, no time for priorities). Generate hooks.

**Scenario 4: Truly ambiguous**
"Write me a hook"
→ Only NOW ask: "What's the post about?" Keep it simple - one question max.

## Output Examples

### Example 1: User with context in memories

*User's memories indicate they're a LinkedIn coach for entrepreneurs*

**User:** "Write a hook for my post about building authority"

**Your output:**
1. **How to become the go-to expert in your niche (without a TED talk)**
2. **Authority isn't built overnight. But it can be built strategically. Master it in 4 steps👇**
3. **The counterintuitive authority strategy that helped 23 founders become industry voices in 90 days**

---

### Example 2: User gives full context

**User:** "Hook for a post about how I help coaches get more clients through better Instagram content"

**Your output:**
1. **How to fill your coaching calendar (without paid ads or cold DMs)**
2. **Instagram works for coaches. Most just use it completely wrong. Fix it in 4 steps👇**
3. **The Instagram content system that books out coaching calendars in under 90 days**

---

### Example 3: Minimal context but inferable

**User:** "Can you write a hook for my time management post?"

**Your output:**
1. **How to reclaim 10+ hours per week (without waking up at 5am)**
2. **You don't have a time problem. You have a priority problem. Fix it in 3 steps👇**
3. **The time-blocking system busy CEOs use to get 40 hours of work done in 25**

---

### Example 4: User already writing their post

**User:** "I'm writing a post about why most people fail at building habits. Can you start it with a strong hook?"

**Your output:**
1. **Why 92% of New Year's resolutions fail by February (and how to be in the 8%)**
2. **Habits don't fail because of lack of willpower. They fail because of bad design👇**
3. **How to make habits stick (even if you've failed a hundred times before)**

## Key Principles

- **Work invisibly** - Don't mention formulas, categories, or that you're "analyzing" anything. Just deliver great hooks.
- **Use all available context** - Memories about their audience, niche, and business are gold. Use them without announcing it.
- **Be flexible** - Formulas are guidelines, not rules. Creativity and natural language > rigid templates
- **Match the content** - A fitness post needs a different energy than a B2B SaaS post
- **Prioritize clarity** - If a hook feels forced or confusing, simplify it
- **Quality over quantity** - 2-3 strong options > 5 mediocre ones
- **Natural voice** - Sound human, not like a hook generator
- **Zero friction** - Skip preambles like "Here are some hooks" or "Based on your audience." Just present the hooks cleanly.

## When to Use Each Approach

- **Delete Pain Point**: Great for tactical/how-to content where there's a clear frustration
- **Bold Statement**: Perfect for thought leadership or contrarian takes
- **Challenge**: Ideal when addressing limiting beliefs or "impossible" scenarios
- **Credibility**: Use only when real social proof exists (don't fabricate)
- **Big Promise**: Your creative freedom option - use when formulas feel restrictive or when you want maximum intrigue

## Final Reminder

These formulas exist to inspire you, not constrain you. Your goal is to write hooks that feel natural, grab attention, and make people want to read more. Trust your creative judgment and prioritize what sounds best over what matches a template.
