---
name: carousel-generator
description: "Generate a carousel from prompt"
---

Skill created by Laxman Meghwal

---

  ## CRITICAL RULE — DO THIS BEFORE ANYTHING ELSE

  **You must NEVER generate a carousel without first asking the questions in Step 1.**

  Even if the user says "make me a carousel about X," your ONLY response is to ask the onboarding questions below. Do not generate any HTML, do not pick any defaults silently, do not skip questions. Ask first. Always.

  "Do NOT use interactive button widgets or ask_user_input tools. Write all 10 questions as plain numbered text in a single message and wait for the user to reply."

  ---

  ## Step 1: Ask These Questions First — No Exceptions

  Before writing a single line of HTML, ask the user for all of the following in one message:

  > "Before I build your carousel, I need a few details:
  >
  > 1. **Who is this carousel for?** (Your name or brand name — this will appear on the cover and final slide)
  > 2. **What's your LinkedIn handle?** (e.g. @yourname — shown in the creator badge)
  > 3. **What is the carousel about?** (Topic, angle, or specific argument you want to make)
  > 4. **Who is your target audience?** (e.g. founders, SDRs, CMOs, job seekers — helps calibrate tone and vocabulary)
  > 5. **Primary brand color** — paste a hex code, or describe it and I'll pick one that fits
  > 6. **How many slides?** — Punchy (6–8), standard (9–12), or deep-dive (13–16)? Default is 10.
  > 7. **Tone** — Analytical / Tactical / Bold & provocative / Conversational / Storytelling / Minimal
  > 8. **Font vibe** — Editorial (serif + sans) / Sharp & technical / Warm & rounded / Bold & expressive / Clean modern
  > 9. **Logo or photo** — Do you have an SVG logo, want to use your initials, or have a profile photo to include on the cover?
  > 10. **Call to action** — What should the last slide ask readers to do? (Follow / Save this post / DM me / Comment below / Visit link in bio)"

  Wait for answers. Do not proceed until you have at least the topic, brand color, name, and handle. For anything else left blank, state your choice explicitly before building.

  ---

  ## Step 2: Build the Color System

  From the user's single primary brand color, derive the full 7-token palette before writing any CSS:

  ```
  CORE        = {user's color}                  // Primary accent — numbers, icons, borders
  CORE_SOFT   = {primary at 12% opacity}        // Subtle fill backgrounds, tag chips
  CORE_LIGHT  = {primary lightened ~28%}        // Secondary accent on dark slides
  CORE_DEEP   = {primary darkened ~35%}         // Gradient anchor, high-contrast text
  CANVAS      = {tinted off-white}              // Light slide background — never pure #fff
  CANVAS_RULE = {1–2 shades darker than CANVAS} // Dividers, borders on light slides
  INK         = {near-black, brand-tempered}    // Dark slide background
  ```

  **Derivation rules:**
  - Warm primaries (reds, oranges, golds) → CANVAS: `#FAF8F4`, INK: `#1A1714`
  - Cool primaries (blues, greens, purples) → CANVAS: `#F3F6FA`, INK: `#0D1421`
  - Neutral primaries → CANVAS: `#F7F7F5`, INK: `#141414`
  - Brand gradient (cover + CTA slides): `linear-gradient(150deg, CORE_DEEP 0%, CORE 55%, CORE_LIGHT 100%)`
  - Noise overlay on gradient slides: use a CSS pattern at 3–5% opacity for depth

  ---

  ## Step 3: Set Typography

  Pick the heading and body font based on the user's stated vibe. Import from Google Fonts.

  **Pairings:**

  | Vibe | Heading | Body | Best for |
  |------|---------|------|----------|
  | Editorial / premium | DM Serif Display | DM Sans | Finance, exec, consulting |
  | Bold / expressive | Fraunces | Outfit | Storytelling, culture, strong POV |
  | Sharp / technical | Space Grotesk 700 | Space Grotesk 400 | SaaS, product, data |
  | Warm / human | Lora | Nunito Sans | Coaching, HR, personal brand |
  | Clean / modern | Plus Jakarta Sans 800 | Plus Jakarta Sans 400 | GTM, startups, generalist |
  | Authoritative | Libre Baskerville | Work Sans | Thought leadership, legal |
  | Energetic / loud | Syne 800 | Outfit | Marketing, growth, hot takes |

  **Type scale (do not deviate):**
  - Cover headline: 36–42px, weight 700–800, line-height 1.05, letter-spacing -0.6 to -0.9px
  - Slide headings: 26–30px, weight 700, line-height 1.1, letter-spacing -0.3px
  - Body text: 14px, weight 400, line-height 1.55–1.6
  - Eyebrow labels: 9px, weight 700, letter-spacing 2.5px, UPPERCASE
  - Slide counters: heading font, 11px, weight 300, letter-spacing 1.5px
  - Supporting small text: 11px, opacity 0.45–0.55

  Apply via two CSS classes: `.head` (heading font) `.body` (body font).

  ---

  ## Slide Format

  - **Aspect ratio:** 1:1 square
  - **Preview size:** 540×540px (inside the HTML prototype)
  - **Export size:** 1080×1080px (via Playwright `device_scale_factor: 2`)
  - Each slide is a fully self-contained 540×540px block — no UI chrome overlaps its content
  - Alternate CANVAS and INK backgrounds to create visual rhythm; use gradient only for Cover and CTA

  ---

  ## Required Elements on Every Slide

  ### 1. Slide Counter (bottom-left)

  - Format: `01 / 10` — zero-padded, heading font, 11px, weight 300, letter-spacing 1.5px
  - Position: absolute, bottom 18px, left 28px
  - Color: `rgba(0,0,0,0.22)` on light slides / `rgba(255,255,255,0.3)` on dark / `rgba(255,255,255,0.4)` on gradient

  ### 2. Swipe Arrow (right edge — all slides except last)

  - Position: absolute right, full height, 44px wide
  - Background: edge fade from transparent
  - Chevron: 20×20 SVG, round caps

  ### 3. Save Prompt (CTA slide only, bottom-right)

  - Bookmark icon + "Save this post" text
  - Position: bottom-right, subtle opacity

  ---

  ## Slide Content Components

  ### Eyebrow Tag
  Inline-block, 9px, weight 700, letter-spacing 2.5px, uppercase, in CORE color.

  ### Creator Badge (Cover and CTA slides)
  Avatar circle (initials or headshot) + Full Name + @handle · LinkedIn.

  ### Stat Callout Block
  Large number (48px, weight 800) + label + source. CORE_SOFT background with left CORE border.

  ### Numbered Insight Row (light/dark variants)
  Large number + title + detail. Light version uses CORE accent, dark version uses CORE_LIGHT.

  ### Before / After Comparison
  Two-column grid. "Before" in muted background, "After" in CORE_SOFT with CORE border.

  ### Pull Quote (standalone slide)
  Large opening quote mark + italic quote text + CORE divider bar.

  ### Strikethrough Pill
  Old/incorrect approach shown as crossed-out pill tag.

  ### Feature / Benefit Row with Icon
  Emoji icon + bold label + description. Used for lists of benefits.

  ### CTA Button (final slide only)
  Rounded pill button, white background, CORE_DEEP text, 14px bold.

  ---

  ## Decorative Design Elements — MUST USE

  These are not optional. Every slide must include at least one decorative element to avoid a flat, plain look.

  ### On light slides:
  - Large soft circle (260px, CORE at 6% opacity) top-right or top-left
  - Smaller accent circle (100px, CORE at 4% opacity)

  ### On dark slides:
  - Radial dot grid pattern (rgba white at 3.5% opacity, 22px spacing)
  - Large tinted circle (300px, CORE at 8% opacity)

  ### On gradient slides:
  - Concentric rings (400px, 300px, 200px) at 7% opacity

  ---

  ## Standard Slide Sequence

  | # | Type | Background | Purpose |
  |---|------|------------|---------|
  | 1 | Cover | Gradient | Bold hook — a specific, debatable claim. Creator badge. No body text. |
  | 2 | Problem / Context | INK | Frame the pain or mistake. Use strikethrough pills for "old way." |
  | 3 | Core Argument | CANVAS | Your single most important idea, plainly stated. |
  | 4–N-2 | Content slides | Alternate INK / CANVAS | Steps, stats, comparisons, frameworks. One idea per slide. |
  | N-1 | Summary / Recap | INK | 3–5 bullet TL;DR of the whole deck. Most-saved slide type. |
  | N | CTA | Gradient | Creator badge, CTA button, save prompt. No swipe arrow. |

  **Cover rules:**
  - Must contain a specific, bold, mildly provocative claim — not a topic title
  - Subtitle allowed (max 1 line, 13px)
  - Creator badge anchored to bottom-left

  **Summary slide rules:**
  - Headline: "Here's the full picture:" or "The recap:"
  - 3–5 bullet rows with thin left rule in CORE color
  - This is the highest-save slide. Give it design weight.

  **CTA slide rules:**
  - No swipe arrow (signals the end)
  - Creator badge at top-center
  - Headline: punchy and specific
  - CTA button centered below headline
  - Save prompt bottom-right

  ---

  ## LinkedIn Preview Frame

  Wrap slides in a LinkedIn-style document post frame for in-chat preview. The frame must be exactly **540px wide**.

  Required frame elements:
  - **Header:** Avatar circle + creator name + "1st" degree badge + "Document" post type tag
  - **Viewport:** 540×540 swipeable slide track
  - **Dot indicators:** Small dots below the viewport — active dot fills with CORE color
  - **Page label:** `Slide 3 of 10` text below the dots
  - **Action bar:** LinkedIn-style icons — Like, Comment, Repost, Send + Bookmark
  - **Caption:** First ~120 chars of suggested caption + "...see more"

  Include swipe/drag JavaScript that updates both dots and pager label.

  ---

  ## PNG Download — Individual Slides

  After generating the HTML carousel, include a **Download Panel** section below the LinkedIn frame.

  - Uses html2canvas for browser-based rendering
  - One download button per slide plus a "Download All" button
  - Downloads each slide as 1080×1080px PNG
  - Web fonts require a moment to load before downloading

  ---

  ## High-Quality Export via Playwright (Optional)

  Python script using Playwright for guaranteed font rendering and lossless quality:

  - Viewport: 540×540, device_scale_factor: 2.0
  - Wait for fonts: `wait_for_timeout(3500)` after `set_content`
  - Hide frame chrome before capture
  - Save with zero-padded filenames (`slide_01.png` through `slide_10.png`)
  - Optional PDF assembly via PIL

  ---

  ## Common Export Mistakes

  | Mistake | What breaks | Fix |
  |---------|-------------|-----|
  | Viewport set to 1080px | Layout reflows, fonts shrink | Keep viewport 540×540, use `device_scale_factor: 2` |
  | HTML generated via shell script | `$` signs corrupt HTML | Always use Python `Path.write_text()` |
  | External image `src` paths | Images missing in headless | Base64-encode all images inline |
  | No font wait timeout | Fallback system fonts render | `wait_for_timeout(3500)` after `set_content` |
  | Frame chrome not hidden | Export includes header/dots/caption | Hide all `.lk-header`, `.lk-dots`, etc. |
  | Files not zero-padded | Sort order breaks in PDF assembly | Use `.zfill(2)` on all filenames |

  ---

  ## Layout Rules

  1. **Text must never overlap the slide counter.** Reserve the bottom 44px.
  2. **Decorative elements are mandatory.** No flat, plain backgrounds.
  3. **One idea per slide, no exceptions.** LinkedIn readers scan in 2–3 seconds.
  4. **Use real, specific numbers.** Vague claims lose credibility. Concrete data earns saves.
  5. **The cover earns the swipe. The summary earns the save. The CTA earns the follow.** Design effort weighted to these three slides.
  6. **After generating the carousel, offer to write the LinkedIn post caption.** The carousel and caption are one unit.

  ---

  ## Design Principles

  1. **Decorative depth over flat surfaces.** Every slide gets circles, grids, gradients, or overlays.
  2. **Alternating light/dark rhythm.** Sustains visual energy across 10+ slides without fatigue.
  3. **The cover is a billboard.** One bold claim. Creator badge. Nothing else competes.
  4. **Typography carries the argument.** Choose fonts that make ideas feel inevitable, not decorated.
  5. **The summary slide is a cheat code.** A crisp 3–5 line recap is the most-saved content format on LinkedIn. Never skip it.
  6. **The last slide is a landing page.** No swipe arrow, save prompt visible, CTA button, creator badge. It should feel like an arrival.
  7. **Dots are non-negotiable.** Always present below the viewport for reader orientation.
  8. **Download panel is non-negotiable.** Every carousel must include per-slide download buttons.
  9. **Caption is part of the deliverable.** After approving the carousel, always offer to write the post caption.